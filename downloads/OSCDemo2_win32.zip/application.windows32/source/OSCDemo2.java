import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import com.neurogami.leaphacking.*; 
import com.leapmotion.leap.*; 
import java.awt.DisplayMode; 
import java.awt.Frame; 
import java.awt.GraphicsDevice; 
import java.awt.GraphicsEnvironment; 
import processing.core.PApplet; 
import java.util.Map; 
import java.util.Iterator; 
import oscP5.*; 
import netP5.*; 
import java.util.HashMap; 
import oscP5.*; 
import netP5.*; 
import java.util.HashMap; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class OSCDemo2 extends PApplet {










LeapMotionP5 leap;

Configgy config;

float pinchThreshold = 0.9f;

String addrPatternPinch;
String addrPatternCircle;

OscManager osc;

String addressPattern;
String argOrder;
HashMap<Character,Float> args;
String[][] pinchMsgFormats;
int pinchMsgFormatCount;

char SPACE = ' ';
int extendedFingerCount = 0;

float ps;


int textSize = 18;
float locX = 0;
float locY = 0;
float locZ = 0;

int currentState = 0;
int maxStates = 1;
HashMap<Integer,String> stateMap;
HashMap<Integer,Integer> muteMap;


int lastMuteChange  = millis();
int lastStateChange = millis();
int SPACE_CHANGE_DELAY = 100;
int STATE_CHANGE_DELAY = 1000;

int placementFlag = 0;

boolean handSpread;
boolean handSpreadSwipe;
float currentConfidence; 
GestureList gestureList;  

// This example is going to end up with a number of things
// that are specific to the song and the designated OSC messages
// A better sketch might have  away to isolate these things
// or make them configurable or something.

boolean[] trackMuteLastSent = new boolean[5];

//-------------------------------------------------------------------
public void setup() {
  config = new Configgy("config.jsi");  

  for(int x=0; x< trackMuteLastSent.length; x++) 
      trackMuteLastSent[x] = false;

  frame.removeNotify();
  frame.setUndecorated(true);
  frame.addNotify();

  size(config.getInt("width"), config.getInt("height")); // Is there a better rendering option?
  noLoop(); // The sketch will call `redraw` as needed; that in turn calls `draw`

  // Use this constructor: LeapMotionP5(PApplet ownerP, boolean useCallbackListener )
  // It means the Leap listener will call back to the onFrame method defined here
  leap = new LeapMotionP5(this, true);
  leap.allowBackgroundProcessing(true);

  currentConfidence = 0.0f;

  // Currently, the callback approach does not let you do stuff in the
  // Listner instance onInit to set gestreu stuff.  But you can still do it by grabbing
  // the Controller instance that is part of the LeapMotionP5 instance.
  leap.controller.setPolicy(Controller.PolicyFlag.POLICY_BACKGROUND_FRAMES);
  leap.controller.enableGesture(Gesture.Type.TYPE_SWIPE);
  leap.controller.config().setFloat("Gesture.Swipe.MinLength", 66000.0f);
  leap.controller.config().save();


  frame.setAlwaysOnTop(true);
  placementFlag = 0;

  brushWidth = config.getInt("brushWidth");
  pinchThreshold = config.getFloat("pinchThreshold");

  args =  new HashMap<Character,Float>();
  osc = new OscManager(config);

  stateMap = config.getHashMapN("states"); 
  muteMap = config.getHashMapNN("muteMapping"); 
  maxStates = stateMap.size();

  setCurrentMessages();
  lastStateChange = millis();

}




//-------------------------------------------------------------------
public void draw() {
  background(255);
  textSize(textSize);
  fill(20);
  text(currentState, 4, textSize+4);
  text(extendedFingerCount, height-textSize, width-textSize);
  // TODO: Find out why the placement code needs repeated invocation
  if (placementFlag < 2) { placeWindow(); }

  updateCursorValues();  
  renderCursor();
  renderConfidenceBorder();
}


public int getExtendedFingerCount(FingerList fingers) {
  int n = 0;
    for (Finger finger : fingers) {
    if ( finger.isExtended() ) n++;
  }

    return n;

}

//-------------------------------------------------------------------
public void onFrame(com.leapmotion.leap.Controller controller) {
  com.leapmotion.leap.Frame frame = controller.frame();
  InteractionBox box = frame.interactionBox();
  HandList hands = frame.hands();
  extendedFingerCount  = 0;

  if (hands.count() > 0 ) {
    Hand hand = hands.get(0);
    currentConfidence = hand.confidence(); 
    FingerList fingers = hand.fingers();
    extendedFingerCount = getExtendedFingerCount(fingers);
    if (extendedFingerCount > 0) {
      gestureList = frame.gestures();
      detectOpenHandSwipe(hand);
      avgPos = Vector.zero();
      ps = constrain(hand.pinchStrength(), 0.0f, 1.0f);

      for (Finger finger : fingers) {
        avgPos  = avgPos.plus(finger.tipPosition());
      }

      avgPos = avgPos.divide(fingers.count());
      normalizedAvgPos = box.normalizePoint(avgPos, true);

      if (haveOpenHandSwipe() ) {onSwipeEvent();}
      if (havePinch() ) {onPinchEvent();}
    }
    redraw(); 
  } 
}


//////////////////////////////////////////////////

//------------------------------------------------------------
public boolean haveSpreadHand() {
  return handSpread;
}

//------------------------------------------------------------
public void detectHandSpread(Hand h) {
  handSpread = false;
  if (h.fingers().count() < 5 )  return;
  for (Finger finger : h.fingers()) {
    if ( !finger.isExtended() ) return ;
  }
  handSpread = true;
}

//------------------------------------------------------------
public float currentConfidence() {
  return currentConfidence;
}

//------------------------------------------------------------
public boolean haveOpenHandSwipe()  {
  return handSpreadSwipe;
}

//------------------------------------------------------------
public void detectOpenHandSwipe(Hand h) {

  handSpreadSwipe = false;
  detectHandSpread(h);
  if (!haveSpreadHand() )  return;
  if ( gestureList.count() ==  0 ) return ;
  handSpreadSwipe = true;
}

//------------------------------------------------------------
public boolean havePinch() {
  if (ps > pinchThreshold ) return true; 
  return false;

}

//-------------------------------------------------------------------
public void setCoordArgs() {
  args.clear();
  args.put('x', normalizedAvgPos.getX() );
  args.put('y', normalizedAvgPos.getY());
  args.put('z', normalizedAvgPos.getZ());
}

//-------------------------------------------------------------------
public void onPinchEvent() {
  setCoordArgs();
  osc.sendBundle(pinchMsgFormats, args );

}

//-------------------------------------------------------------------
public void setCurrentMessages() {
  String mappedMsg = (String) stateMap.get(currentState); 
  pinchMsgFormats =  config.getStringList(mappedMsg);
}

//-------------------------------------------------------------------
public void rotateCurrentState(){
  currentState++;
  currentState %= maxStates;
  setCurrentMessages();
}

//-------------------------------------------------------------------
public void onSwipeEvent() { 
  if (millis() - lastStateChange > STATE_CHANGE_DELAY) { 
    lastStateChange = millis();
    rotateCurrentState(); 
  }
}


public void onSpaceFingers(int numFingers) {
println("* * * * *  onSpaceFingers " + numFingers);
  if (millis() - lastMuteChange > SPACE_CHANGE_DELAY) { 
    lastMuteChange = millis();
    // TODO Figure out a way to make this behavior configurable
    sendMuteOsc(numFingers); 
  }

}


public void keyPressed() {
  if (keyCode == SPACE ) {
    println( " SPACE .. extendedFingerCount = " + extendedFingerCount );
    if (extendedFingerCount > 0) {
      onSpaceFingers(extendedFingerCount); 
    }
  }
}


public void sendMuteOsc(int numFingers) {

println("sendMuteOsc: " + numFingers);
// How do we send no args?
//  So far we have been send string arrays like this:
//  ["/renoise/song/track/2/device/2/set_parameter_by_name", "s:Y-Axis,y"]
   
  String[][] muteMessage = new String[1][2];
  String cmd = "mute";

  if (trackMuteLastSent[numFingers-1]) { /// last sent was true; i.e. mute
      cmd  = "unmute";
     trackMuteLastSent[numFingers-1] = false;
  }     else {
   trackMuteLastSent[numFingers-1] = true;
  }


  println("trackMuteLastSent[numFingers-1] = " + trackMuteLastSent[numFingers-1] );

    muteMessage[0][0] = "/renoise/song/track/"+muteMap.get(numFingers)+"/" + cmd;
    muteMessage[0][1] = "" ;
   osc.sendBundle(muteMessage, args);
}


//-------------------------------------------------------------------
public void placeWindow() {
  GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
  GraphicsDevice[] gs = ge.getScreenDevices();
  java.awt.Rectangle rec = ge.getMaximumWindowBounds();
  int leftLoc = rec.width - width;
  int topLoc = rec.height - height;
  println("Place window at " + leftLoc + ", " + topLoc);
  frame.setLocation(leftLoc, topLoc);
  placementFlag++; 
}



//-------------------------------------------------------------------
//  Configgy reads in a file holding config data.
//  The file format is "sort of json"
//  Each line is assumed to be valid json, absent wrapping braces.
//
//  You can read about this at http://jamesbritt.com/posts/getting-configgy-with-processing.html
//  
//  The basic idea is to make writing simple key:value settings super easy,
//  and more complex entries possible.
//
//  The code is constantly evolving based on usage.
//
//-------------------------------------------------------------------





class Configgy {

  String[] configTextLines;
  JSONObject json;

  Configgy(String configFile) {
    try {
      configTextLines = getDataLines(loadStrings(configFile));

      String line = trim(configTextLines[0]);
      if (line.charAt(0) == '{') {
        json = loadJSONObject(configFile);
      } else {
        String jsonString = configToJson(configTextLines);
        json = parseJSONObject(jsonString);
      }
    } catch(Exception e) {
      println("Error loading data from '" + configFile + "'");
      e.printStackTrace();
    }
  }

  //-------------------------------------------------------------------
  // Return just the lines that have config data
  public String[] getDataLines(String[] configTextLines) {
    String[] dataLines = {};
    String line;

    for (int i=0; i < configTextLines.length; i++) {
      line = trim(configTextLines[i]);
      if ( ( line.indexOf("#") != 0 ) &&  ( line.indexOf(":") > 0 ) )  {
        dataLines = append(dataLines,  line);  
      }
    }
    return dataLines ;
  }


  //-------------------------------------------------------------------
  // Assumes we have a set of congig lines, each being of the form
  //    keyName: validJsonExpression
  public String configToJson(String[] configTextLines) {
    String line;
    String[] jsonStrings = {"{" };
    String[] splitString;
    String newJsonLine = "";
    for (int i=0; i < configTextLines.length; i++) {
      line = trim(configTextLines[i]);

      if ( ( line.indexOf("#") != 0 ) &&  ( line.indexOf(":") > 0 ) )  {
        splitString = split(configTextLines[i], ':'); 
        newJsonLine = "\"" + splitString[0] + "\":"  + join(subset(splitString,1), ":" ) + ", ";
        jsonStrings = append(jsonStrings,  newJsonLine);  

      }
    }

    jsonStrings = append(jsonStrings, "}"  );  
    return  join(jsonStrings, "\n");
  }


  //-------------------------------------------------------------------
  // Assorted accessor methods
  public String getValue(String k) { return json.getString(k); }

  //-------------------------------------------------------------------
  public String getValue(String k, String defaultVal ) { 
    String val = defaultVal;
    try {
      val =  json.getString(k); 
      return val;
    } catch(Exception e) {
      return defaultVal;
    }
  }

  //-------------------------------------------------------------------
  public String getString(String k) { return json.getString(k); }

  //-------------------------------------------------------------------
  public String getString(String k, String defaultVal ) { 
    String val = defaultVal;
    try {
      val =  json.getString(k); 
      return val;
    } catch(Exception e) {
      return defaultVal;
    }
  }


  //-------------------------------------------------------------------
  public int getInt(String k) { return json.getInt(k); }

  //-------------------------------------------------------------------
  public int getInt(String k, int defaultVal ) { 
    int val = defaultVal;

    try {
      val = json.getInt(k);
      return val;

    } catch(Exception e) {
      return defaultVal;
    }
  }

  //-------------------------------------------------------------------
  public float getFloat(String k) { return json.getFloat(k); }

  //-------------------------------------------------------------------
  public float getFloat(String k, float defaultVal ) { 
    float val = defaultVal;

    try {
      val = json.getFloat(k);
      return val;

    } catch(Exception e) {
      return defaultVal;
    }
  }

  //-------------------------------------------------------------------
  public boolean getBoolean(String k) { return json.getBoolean(k); }

  //-------------------------------------------------------------------
  public boolean getBoolean(String k, boolean defaultVal) { 
    boolean val = defaultVal;

    try {
      val = json.getBoolean(k);
      return val;
    } catch(Exception e) {
      return defaultVal;
    }
  }

  //--------------------------------------------------------------
  public String[][] getStringList(String k) {
    JSONArray values = json.getJSONArray(k);
    String[][] strings = new String[values.size()][2];
    for (int i = 0; i < values.size(); i++) {
      strings[i] = jsonArrayToStrings(values.getJSONArray(i));
    }
    return strings;
  }

  //--------------------------------------------------------------
  public String[] jsonArrayToStrings( JSONArray values ) {
    String[] strings = new String[values.size()];
    for (int i = 0; i < values.size(); i++) {
      strings[i] = values.getString(i);
    }
    return strings;
  }



  //--------------------------------------------------------------
  //  NOTE: Things asplode if you call the wrong 'getXXX' method
  public String[] getStrings(String k) {
    JSONArray values = json.getJSONArray(k);
    String[] strings = new String[values.size()];
    for (int i = 0; i < values.size(); i++) {
      strings[i] = values.getString(i);
    }
    return strings;
  }

  //-------------------------------------------------------------------
  // Assumes the JSON "hashmap" is string:string.
  // Might look at adding some ways to get other kinds of maps.
  // However, if the client really needs, say, strings and ints then
  // the values returned can be casted or otherwise converted.
  public HashMap<String,String> getHashMap(String k) {
    HashMap<String, String> h = new HashMap<String, String>();
    JSONObject jo = json.getJSONObject(k);

    Iterator keys = jo.keyIterator();

    while( keys.hasNext() ) {
      String key_name = (String) keys.next(); 
      h.put(key_name,  jo.getString(key_name));
    }
    return h;
  }

  //-------------------------------------------------------------------
  public HashMap<Integer,String> getHashMapN(String k) {

    HashMap<Integer, String> h = new HashMap<Integer, String>();
    JSONObject jo = json.getJSONObject(k);

    Iterator keys = jo.keyIterator();

    while( keys.hasNext() ) {
      String key_name = (String) keys.next(); 
      h.put(parseInt(key_name),  jo.getString(key_name));
    }
    return h;

  }


//-------------------------------------------------------------------
// The naming has gotne WAY hackish
  public HashMap<Integer,Integer> getHashMapNN(String k) {

    HashMap<Integer,Integer> h = new HashMap<Integer,Integer>();
    JSONObject jo = json.getJSONObject(k);

    Iterator keys = jo.keyIterator();

    while( keys.hasNext() ) {
      String key_name = (String) keys.next(); 
      h.put(parseInt(key_name),  jo.getInt(key_name));
    }
    return h;

  }

  //-------------------------------------------------------------------
  public int[] getInts(String k) {
    JSONArray values = json.getJSONArray(k);
    int[] ints = new int[values.size()];
    for (int i = 0; i < values.size(); i++) {
      ints[i] = values.getInt(i); 
    }
    return ints;
  }

  //-------------------------------------------------------------------
  public float[] getFloats(String k) {
    JSONArray values = json.getJSONArray(k);
    float[] floats = new float[values.size()];
    for (int i = 0; i < values.size(); i++) {
      floats[i] = values.getFloat(i); 
    }
    return floats;
  }


  //-------------------------------------------------------------------
  public boolean[] getBooleans(String k) {
    JSONArray values = json.getJSONArray(k);
    boolean[] booleans= new boolean[values.size()];
    for (int i = 0; i < values.size(); i++) {
      booleans[i] = values.getBoolean(i); 
    }
    return booleans;
  }

}


com.leapmotion.leap.Vector avgPos           = com.leapmotion.leap.Vector.zero();
com.leapmotion.leap.Vector normalizedAvgPos = com.leapmotion.leap.Vector.zero();

int   zMap = 0;
int   y    = 0; 
int   x    = 0; 

int brushWidth = 20;
boolean DEBUG = true;

//-------------------------------------------------------------------
public void d(String msg) { if (DEBUG) println(msg); }

//-------------------------------------------------------------------
public int mapXforScreen(float xx) {
  return( PApplet.parseInt( map(xx, 0.0f, 1.0f, 0.0f, width) ) );
}

//-------------------------------------------------------------------
public int mapYforScreen(float yy) {
  return( PApplet.parseInt( map(yy, 0.0f, 1.0f,  height, 0) ) );
}

//-------------------------------------------------------------------
public void updateCursorValues() {
  zMap = 10; // FIXME Magic numbers are bad news.
  if ( havePinch() ) { zMap = 100; }
  y = mapYforScreen( normalizedAvgPos.getY() );
  x = mapXforScreen(normalizedAvgPos.getX()); 
}

//-------------------------------------------------------------------
public void renderCursor() {
  colorMode(HSB);
  fill(zMap, 255, 255);
  stroke(zMap, 255, 255);
  ellipse(x, y, brushWidth/2, brushWidth/2);
}

//-------------------------------------------------------------------
public void renderConfidenceBorder() {
  strokeWeight(10);
  int redTone = PApplet.parseInt( (1.0f - currentConfidence()) * 255 );
  colorMode(HSB);
  stroke(0, redTone, redTone );
  fill(0,0);
  rect(0,0, width, height);
}



// import java.util.Map;


class OscManager {

  OscP5 oscP5;

  NetAddress oscServer;

  OscMessage msgOn;
  OscMessage msgOff;
  OscMessage msg;



  int renoiseInstr = 0;
  int renoiseTrack = 1;


  /*
     This code needs to drop the Renoise hard-coded stuff and allow for easier 
     sending of whatever OSC.

     The probelm is that OSC messages come in all shpaes and sizes.

     An ideal solution would allow something like:

     sendOSC( "/my/cool/address/pattern", 0.3, "Some string", 5);

     This would require a Java/Processing method that accepted near-arbitrary arguments.

     That might not be a possible thing.

     The next option might be to pass all that stuff as a single argument, a list thing.


     A third thing might be to use a single carefully-crafted string:

     sendOSC( "/my/cool/address/pattern  0.3 'Some string' 5");

     or something.

     Then some other code would need to figure out what that meant.

     Option 2 is possible: http://stackoverflow.com/questions/16363547/how-to-declare-an-array-of-different-data-types

     but it has a problem in common with option 3: How does the code know the types of OSC arguments?


     There is Ruby code that does some regexy stuff to sort out what something is.

     It feels fragile to try to port it to Java.

     Some othre ideas:

     Require the use to define their OSC calls in some special file.  

     Then call those with runtime values.

Or: Require OSC commands to look like this:

[  "/my/cool/address/pattern", "fsi",  "0.3",  "Some string", "5" ]

An array of strings that use the first 2 items for the address pattern and tag types.


Is there some way to cache any of the evaluation?  Store what we know about an OSC message pattern?

There's still parsing, but splitting the tag type into chars seems easier tha guessing data types.


This approach works, though there is some latency.

What if there were also some arg-specific methods? for example:
   * oscInt1(addressPattern,  n1)
   * oscInt2(addressPattern,  n1, n2)

   Many OSC servers do work with a fairly smallish range of argument options. 

   So provide semi-generic "args of these kinds" methods to avoid doing type parsing.



   */
  /***************************************************************/
  OscManager(Configgy config ) {
    // println("Creating an OscManager!");
    oscP5 = new OscP5(this, config.getInt("oscListeningPort"));
    oscServer = new NetAddress(config.getString("oscServerIP"), config.getInt("oscServerPort"));
  }

 //   /***************************************************************/
 //   public void sendMessage(String[] addrPatternAndArgs, HashMap<Character,Float> args ) {
 //     println("* send OSC message to " + addrPatternAndArgs );
 //     ThreadedOscSend _ts = new ThreadedOscSend(oscP5, oscServer);
 //     _ts.setBundleData(addrPatternAndArgs, args);
 // 
 //     new Thread(_ts).start();
 //   }


  /***************************************************************/
  public void sendBundle(String[][] addrPatternAndArgsArray, HashMap<Character,Float> args ) {
    // println("* send OSC BUNDLE to " + addrPatternAndArgsArray );
    ThreadedOscSend _ts = new ThreadedOscSend(oscP5, oscServer);
    _ts.setBundleData(addrPatternAndArgsArray, args);
    new Thread(_ts).start();
  }



}






//-------------------------------------------------------------------
class ThreadedOscSend extends Thread {

  OscMessage msg;
  OscBundle  bundle;
  String[]   argStrings;
  String[][] addrPatternAndArgsArray;
  HashMap<Character,Float> args;
  String addressPattern;

  NetAddress remoteOscServer;
  OscP5 oscP5;
  boolean sendOSC = true;
  boolean haveArgs = false;


  //-------------------------------------------------------------------
  // See if these server things are not available as global stuff thanks to the main sketch
  public ThreadedOscSend(OscP5 oscP5, NetAddress remoteOscServer ){
    this.oscP5 = oscP5;
    this.remoteOscServer = remoteOscServer;
  }

  //-------------------------------------------------------------------
  //   public void setMsgData(String[] addrPatternAndArgs, HashMap<Character,Float> args) {
  //     addressPattern = addrPatternAndArgs[0];
  //     this.argStrings = addrPatternAndArgs[1].split(",");
  //     this.args = args;
  //     this.haveArgs  = false;
  //   }

  //-------------------------------------------------------------------
  // It gets even more tricky if we want that args to contain values other than
  // float, but for now ..
  // FIXME: Think of efficient way to pass args of varying data types. 
  public void setBundleData(String[][] addrPatternAndArgsArray, HashMap<Character,Float> args) {
    this.addrPatternAndArgsArray = addrPatternAndArgsArray;
    this.args = args;
    this.haveArgs  = false;
  }



  //-------------------------------------------------------------------
  //   public void setMsgData(String addrPattern, int i) {
  //     addressPattern = addrPattern;
  //     this.argStrings = argStrings;
  //     this.args = args;
  //     this.haveArgs  = false;
  //   }


  //-------------------------------------------------------------------
  // new version: There is a use caae with Renoise where the message 
  // requires a specific value, and not one from the Leap data.
  // For example:
  //   /renoise/song/track/1/device/2/set_parameter_by_name "X-Axis", <x>
  // So we need a way to hard-code specific values in a list arg info.
  //
  // one way would be to make the config item a list of strings.
  // s[0] is the pattern.  all the rest are args.  If an arg string
  // has a ':' then it indicates a tag type followed by the fixed data.
  // else we assume it is some placeholder for Leap data (whose type
  // will be known).
  //
  // Since this wil never change, can the message be cached and on 
  // future calls just have the Leap values updated?

  public OscMessage makeMessage(String[] msgStuff) {

    String addressPattern = msgStuff[0];

    String[] argStrings     = msgStuff[1].split(",");

    // println("argStrings = " + argStrings ); 
    // println("args = " + args.toString()  ); 
    msg = new OscMessage(addressPattern);
    //String t = "";

    for( String t : argStrings) {
      // FIXME: We assume the tag types are always float,
      // and that what we are checking are hash keys
      // println("t = " + t );
      if (t.indexOf(':') > 0 ) {
        String[] foo = t.split(":");
        switch ( foo[0].charAt(0) ) {
          case 'i':
            msg.add( parseInt( foo[1] ));
            break;
          case 'f':
            msg.add( parseFloat(foo[1]  ));
            break;
          case 's':
            msg.add( foo[1]  );
            break;
        }
      }
      else { 
        if (t.length() > 0 ) {
        // Why does a NPE sometimes occur here?
          if (args.get( t.charAt(0) ) != null  ) {
          msg.add( args.get(t.charAt(0))  );
          }
        }
      }
    }

    return msg;
  }

  //-------------------------------------------------------------------
  public void makeMessages() {
    bundle = new OscBundle();

    for( int i = 0; i < addrPatternAndArgsArray.length;  i++ ){
      bundle.add(makeMessage(addrPatternAndArgsArray[i]));
    }
  }

  //-------------------------------------------------------------------
  public void run(){
    makeMessages();
    //    println("Sending " + msg + " to " + remoteOscServer);
    oscP5.send(bundle, remoteOscServer); 
    //    try {
    //    Thread.sleep(this.duration);
    //} catch(InterruptedException ie) {
    //}

    //    oscP5.send(noteOffMsg, remoteOscServer); 
  }
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "OSCDemo2" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
